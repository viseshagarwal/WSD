import React from 'react';

export default function BookCard() {
  return <div>BookCard</div>;
}
